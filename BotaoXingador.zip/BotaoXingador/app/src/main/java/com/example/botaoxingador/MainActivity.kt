package com.example.botaoxingador

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.LocalOnBackPressedDispatcher
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botaoxingador.ui.theme.BotaoXingadorTheme
import java.util.Locale
import java.util.Random

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val tts: TextToSpeech by lazy {
        TextToSpeech(this, this)
    }

    private val xingamentos: Array<String> by lazy {
        resources.getStringArray(R.array.xingamentos)
    }
    private val random by lazy { Random() }

    companion object {
        const val APP_NAME = "Palavrões do Bem"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val frase = remember { mutableStateOf("Clique no botão para xingar!") }
            BotaoXingadorTheme {
                InsultButtonApp(frase)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("pt", "BR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "A linguagem especificada não é suportada!")
            } else {
                Log.i("TTS", "TextToSpeech Engine inicializado com sucesso!")
            }
        } else {
            Log.e("TTS", "Falha ao inicializar o TextToSpeech Engine.")
        }
    }

    private fun falar(texto: String) {
        try {
            tts.speak(texto, TextToSpeech.QUEUE_FLUSH, null, null)
        } catch (e: Exception) {
            tts.speak("Houve um erro ao falar.", TextToSpeech.QUEUE_FLUSH, null, null)
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        if (tts.isSpeaking) {
            tts.stop()
        }
        tts.shutdown()
        super.onDestroy()
    }

    @Composable
    fun InsultButtonApp(frase: MutableState<String>) {
        val onBackPressedDispatcher = LocalOnBackPressedDispatcher.current

        DisposableEffect(onBackPressedDispatcher) {
            val callback = object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    val randomIndex = random.nextInt(xingamentos.size)
                    val fraseAleatoria = xingamentos[randomIndex]
                    falar(fraseAleatoria)
                }
            }

            onBackPressedDispatcher.addCallback(callback)

            onDispose {
                callback.remove()
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = {
                        val index = random.nextInt(xingamentos.size)
                        val novoXingamento = xingamentos[index]
                        frase.value = novoXingamento
                        falar(novoXingamento)
                    },
                    modifier = Modifier
                        .padding(10.dp)
                        .fillMaxWidth(0.6f),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text(
                        "Aperte Aqui!!",
                        fontSize = 20.sp,
                        color = Color.White
                    )
                }
                Text(
                    text = frase.value,
                    modifier = Modifier
                        .padding(top = 32.dp),
                    fontSize = 24.sp
                )
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun InsultButtonPreview() {
        val frase = remember { mutableStateOf("Clique no botão para xingar!") }
        BotaoXingadorTheme {
            InsultButtonApp(frase)
        }
    }
}